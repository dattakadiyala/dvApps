﻿/// <reference path="jquery-1.9.1.min.js" />

/// <reference path="jquery.mobile-1.3.0.js" />

/// <reference path="appJS/ActionsPopup.js" />

/// <reference path="appJS/PdaSearch.js" />

/// <reference path="appJS/actionToken.js" />

/// <reference path="appJS/appBI.js" />

/// <reference path="appJS/appDB.js" />

/// <reference path="appJS/appGenericBinding.js" />

/// <reference path="appJS/appUI.js" />

/// <reference path="appJS/binding.js" />

/// <reference path="appJS/DashBoard.js" />

/// <reference path="appJS/DemandOrders.js" />

